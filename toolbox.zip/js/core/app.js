// ============================================================
//  🚀 应用核心 - 负责模块管理和Tab切换
// ============================================================
const App = {
    modules: {},
    currentTab: 'petRing',

    register(module) {
        if (!module.id) {
            console.error('模块缺少 id');
            return;
        }
        this.modules[module.id] = module;
        console.log(`✅ 模块已注册: ${module.id}`);
    },

    switchTab(tabId) {
        // 隐藏所有tab内容
        document.querySelectorAll('.tab-content').forEach(el => {
            el.classList.remove('active');
        });

        // 取消所有tab按钮的高亮
        document.querySelectorAll('.tab-nav .tab-btn').forEach(el => {
            el.classList.remove('active');
        });

        // 显示目标tab
        const target = document.getElementById('tab-' + tabId);
        if (target) {
            target.classList.add('active');
        } else {
            console.warn('找不到Tab容器: tab-' + tabId);
        }

        const btn = document.querySelector(`.tab-nav .tab-btn[data-tab="${tabId}"]`);
        if (btn) {
            btn.classList.add('active');
        } else {
            console.warn('找不到Tab按钮: [data-tab="' + tabId + '"]');
        }

        this.currentTab = tabId;

        // 如果模块有 render 方法，调用它
        if (this.modules[tabId] && typeof this.modules[tabId].render === 'function') {
            console.log(`🔄 渲染模块: ${tabId}`);
            this.modules[tabId].render();
        } else {
            console.warn(`模块 ${tabId} 没有 render 方法`);
        }
    },

    refreshAll() {
        for (let [id, module] of Object.entries(this.modules)) {
            if (typeof module.render === 'function') {
                console.log(`🔄 刷新模块: ${id}`);
                module.render();
            }
        }
    },

    getModule(id) {
        return this.modules[id] || null;
    },

    init() {
        console.log('🚀 App 启动中...');

        // 1. 绑定Tab切换事件
        document.querySelectorAll('.tab-nav .tab-btn').forEach(btn => {
            // 移除旧事件，防止重复绑定
            btn.removeEventListener('click', btn._clickHandler);
            // 绑定新事件
            const handler = function() {
                const tabId = this.dataset.tab;
                console.log(`🖱️ 点击Tab: ${tabId}`);
                App.switchTab(tabId);
            };
            btn._clickHandler = handler;
            btn.addEventListener('click', handler);
        });

        // 2. 让所有已注册的模块初始化
        for (let [id, module] of Object.entries(this.modules)) {
            if (typeof module.init === 'function') {
                console.log(`📦 初始化模块: ${id}`);
                try {
                    module.init();
                } catch (e) {
                    console.error(`❌ 模块 ${id} 初始化失败:`, e);
                }
            }
        }

        // 3. 默认显示第一个tab
        const firstTab = document.querySelector('.tab-nav .tab-btn.active');
        if (firstTab) {
            this.switchTab(firstTab.dataset.tab);
        } else {
            this.switchTab('petRing');
        }

        console.log('✅ App 启动完成！');
    }
};

window.App = App;