// ============================================================
//  ☁️ 同步核心 - 负责 GitHub 云端同步
//  依赖 Storage（已加载）
// ============================================================
const GitHubSync = {
    token: '',
    repoOwner: '',
    repoName: '',
    filePath: 'db.json',

    // 配置
    config(options) {
        Object.assign(this, options);
    },

    // 同步到云端
    async syncToCloud() {
        if (!this.token) {
            return { success: false, message: '❌ 请先配置 GitHub Token' };
        }

        const data = {
            version: '2.0',
            timestamp: new Date().toISOString(),
            modules: Storage.getAll()
        };

        const url = `https://api.github.com/repos/${this.repoOwner}/${this.repoName}/contents/${this.filePath}`;
        let sha = null;

        try {
            // 1. 获取当前文件版本（SHA）
            const getRes = await fetch(url, {
                headers: {
                    'Authorization': `token ${this.token}`,
                    'Accept': 'application/vnd.github.v3+json'
                }
            });
            if (getRes.ok) {
                const info = await getRes.json();
                sha = info.sha;
            }

            // 2. 上传新数据
            const content = btoa(unescape(encodeURIComponent(JSON.stringify(data, null, 2))));
            const putRes = await fetch(url, {
                method: 'PUT',
                headers: {
                    'Authorization': `token ${this.token}`,
                    'Accept': 'application/vnd.github.v3+json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    message: `更新数据 - ${new Date().toLocaleString()}`,
                    content: content,
                    sha: sha
                })
            });

            if (putRes.ok) {
                return { success: true, message: '✅ 同步成功！' };
            } else {
                const err = await putRes.json();
                return { success: false, message: '❌ 同步失败：' + (err.message || '未知错误') };
            }
        } catch (error) {
            return { success: false, message: '❌ 网络错误：' + error.message };
        }
    },

    // 从云端拉取
    async syncFromCloud() {
        if (!this.token) {
            return { success: false, message: '❌ 请先配置 GitHub Token' };
        }

        const url = `https://api.github.com/repos/${this.repoOwner}/${this.repoName}/contents/${this.filePath}`;

        try {
            const res = await fetch(url, {
                headers: {
                    'Authorization': `token ${this.token}`,
                    'Accept': 'application/vnd.github.v3+json'
                }
            });

            if (!res.ok) {
                const err = await res.json();
                return { success: false, message: '❌ 拉取失败：' + (err.message || '文件不存在') };
            }

            const data = await res.json();
            const content = JSON.parse(decodeURIComponent(escape(atob(data.content))));

            if (content.modules) {
                Storage.importAll(content.modules);
                return { success: true, message: '✅ 拉取成功！', data: content };
            } else {
                return { success: false, message: '❌ 数据格式不兼容' };
            }
        } catch (error) {
            return { success: false, message: '❌ 网络错误：' + error.message };
        }
    }
};

window.GitHubSync = GitHubSync;