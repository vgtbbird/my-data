// ============================================================
//  📦 存储核心 - 所有数据读写都通过这里
//  这是最底层，谁都不依赖
// ============================================================
const Storage = {
    // 保存数据
    set(moduleKey, data) {
        try {
            localStorage.setItem(`toolbox_${moduleKey}`, JSON.stringify(data));
            return true;
        } catch (e) {
            console.error('保存失败:', e);
            return false;
        }
    },

    // 读取数据
    get(moduleKey, defaultValue = null) {
        try {
            const data = localStorage.getItem(`toolbox_${moduleKey}`);
            return data ? JSON.parse(data) : defaultValue;
        } catch (e) {
            console.error('读取失败:', e);
            return defaultValue;
        }
    },

    // 删除数据
    remove(moduleKey) {
        localStorage.removeItem(`toolbox_${moduleKey}`);
    },

    // 获取所有模块数据（用于同步）
    getAll() {
        const all = {};
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && key.startsWith('toolbox_')) {
                const moduleKey = key.replace('toolbox_', '');
                try {
                    all[moduleKey] = JSON.parse(localStorage.getItem(key));
                } catch (e) {
                    all[moduleKey] = localStorage.getItem(key);
                }
            }
        }
        return all;
    },

    // 批量导入（从云端拉取时用）
    importAll(data) {
        for (let [key, value] of Object.entries(data)) {
            localStorage.setItem(`toolbox_${key}`, JSON.stringify(value));
        }
    }
};

window.Storage = Storage;