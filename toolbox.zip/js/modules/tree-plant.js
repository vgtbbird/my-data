// ============================================================
//  🌳 种树模块
// ============================================================
const TreePlantModule = {
    id: 'treePlant',

    // ========== 数据 ==========
    storageKey: 'treePlant',
    history: [],
    prices: {},
    current: { seedCost: 45, baseShakes: 6, shakes: 6, events: [], loot: {} },

    LOOT_TYPES: [
        { key: 'eryao', label: '二药', defaultPrice: 1.5 },
        { key: 'bishui', label: '避水珠', defaultPrice: 5 },
        { key: 'dinghun', label: '定魂珠', defaultPrice: 18 },
        { key: 'jingang', label: '金刚石', defaultPrice: 18 },
        { key: 'yeguang', label: '夜光珠', defaultPrice: 12 },
        { key: 'longlin', label: '龙鳞', defaultPrice: 8 },
        { key: 'money', label: '金钱(万)', defaultPrice: 2.75 },
        { key: 'exp', label: '经验', defaultPrice: 0 },
        { key: 'shoujue', label: '兽决', defaultPrice: 80 },
        { key: 'lingpai', label: '令牌', defaultPrice: 450 },
        { key: 'baoshi', label: '宝石', defaultPrice: 8 },
        { key: 'caiguo', label: '彩果', defaultPrice: 80 },
        { key: 'haima', label: '海马', defaultPrice: 15 },
    ],

    // ========== 生命周期 ==========
    init() {
        this.loadData();
        this.buildUI();
        this.bindEvents();
        App.register(this);
        this.render();
    },

    render() {
        const container = document.getElementById('treePlantContainer');
        if (!container) {
            console.error('❌ 找不到 treePlantContainer');
            return;
        }
        if (!container.innerHTML || container.innerHTML.trim() === '' || !container.querySelector('.stats-grid')) {
            this.buildUI();
        }
        this.updateStats();
        this.updateCurrent();
        this.updateHistory();
        this.updateAnalysis();
        this.saveData();
    },

    // ========== 数据操作 ==========
    loadData() {
        const data = Storage.get(this.storageKey, {});
        this.history = data.history || [];
        this.prices = data.prices || {};
        this.current = data.current || { seedCost: 45, baseShakes: 6, shakes: 6, events: [], loot: {} };

        this.LOOT_TYPES.forEach(t => {
            if (this.current.loot[t.key] === undefined) this.current.loot[t.key] = 0;
            if (this.prices[t.key] === undefined) this.prices[t.key] = t.defaultPrice;
        });
    },

    saveData() {
        Storage.set(this.storageKey, {
            history: this.history,
            prices: this.prices,
            current: this.current
        });
    },

    // ========== 计算 ==========
    calcStats() {
        let totalCost = 0,
            totalIncome = 0,
            totalProfit = 0,
            winCount = 0;
        for (let h of this.history) {
            totalCost += h.cost || 0;
            totalIncome += h.income || 0;
            totalProfit += h.profit || 0;
            if (h.profit > 0) winCount++;
        }
        const count = this.history.length;
        return {
            totalCost,
            totalIncome,
            totalProfit,
            count,
            avgProfit: count > 0 ? totalProfit / count : 0,
            winRate: count > 0 ? (winCount / count * 100) : 0
        };
    },

    calcCurrentIncome() {
        let total = 0;
        const details = [];
        for (let [key, count] of Object.entries(this.current.loot)) {
            if (count > 0) {
                const price = this.prices[key] || 0;
                const val = count * price;
                total += val;
                const label = this.LOOT_TYPES.find(t => t.key === key)?.label || key;
                details.push(`${label}×${count}=${val.toFixed(1)}万`);
            }
        }
        return { total, details };
    },

    // ========== 构建UI ==========
    buildUI() {
        const container = document.getElementById('treePlantContainer');
        if (!container) return;

        container.innerHTML = `
            <!-- 统计卡片 -->
            <div class="stats-grid">
                <div class="stat-item"><div class="num" id="trTotalCost">0</div><div class="label">💰 总成本(万)</div></div>
                <div class="stat-item"><div class="num" id="trTotalIncome">0</div><div class="label">📊 总收入(万)</div></div>
                <div class="stat-item" id="trProfitStat"><div class="num" id="trTotalProfit">0</div><div class="label">📈 总利润(万)</div></div>
                <div class="stat-item"><div class="num" id="trTotalCount">0</div><div class="label">🌳 种植棵数</div></div>
                <div class="stat-item"><div class="num" id="trAvgProfit">0</div><div class="label">📊 平均利润/棵</div></div>
                <div class="stat-item" id="trRateStat"><div class="num" id="trWinRate">0%</div><div class="label">🏆 盈利率</div></div>
            </div>

            <!-- 当前种树 -->
            <div class="module">
                <div class="module-header">
                    <div class="title">🌳 记录当前种树 <span class="hint" id="trCurrentLabel">第 1 棵</span></div>
                    <div><button class="btn-undo" id="trUndoBtn">↩️ 撤销</button></div>
                </div>
                <div class="module-body">
                    <div class="tree-current-box">
                        <div class="info-item">🌱 树苗成本: <span class="val" id="trSeedCost">45</span> 万</div>
                        <div class="info-item">🔄 基础摇树: <span class="val" id="trBaseShakes">6</span> 次</div>
                        <div class="info-item">📌 当前次数: <span class="val highlight" id="trCurrentShakes">6</span> 次</div>
                        <div class="info-item">🎯 已触发事件: <span class="val" id="trEventsDisplay">无</span></div>
                    </div>

                    <div style="font-weight:600;font-size:0.8rem;color:#1f3b53;margin:8px 0 4px;">⚡ 特殊事件 (点击累加, 不限次数)</div>
                    <div class="tree-events-grid" id="trEventsGrid">
                        <button class="evt-btn" data-event="xiaozai">🍂 小灾 <span class="sub">(+1次)</span></button>
                        <button class="evt-btn" data-event="chongzai">🐛 虫灾 <span class="sub">(+2次)</span></button>
                        <button class="evt-btn" data-event="zaoshu">🌿 早熟 <span class="sub">(强制6次)</span></button>
                        <button class="evt-btn" data-event="none">⏭️ 无事件 <span class="sub">(重置)</span></button>
                    </div>

                    <div style="font-weight:600;font-size:0.8rem;color:#1f3b53;margin:10px 0 4px;">💎 元宝产出 (点击记录)</div>
                    <div class="tree-loot-grid" id="trLootGrid">
                        <button class="loot-btn" data-loot="eryao">💊 二药 <span class="count" id="tl-eryao">0</span></button>
                        <button class="loot-btn" data-loot="bishui">💧 避水珠 <span class="count" id="tl-bishui">0</span></button>
                        <button class="loot-btn" data-loot="dinghun">🔮 定魂珠 <span class="count" id="tl-dinghun">0</span></button>
                        <button class="loot-btn" data-loot="jingang">💎 金刚石 <span class="count" id="tl-jingang">0</span></button>
                        <button class="loot-btn" data-loot="yeguang">🌙 夜光珠 <span class="count" id="tl-yeguang">0</span></button>
                    </div>
                    <div class="tree-loot-extra" id="trLootExtra">
                        <button class="loot-btn" data-loot="longlin">🐉 龙鳞 <span class="count" id="tl-longlin">0</span></button>
                        <button class="loot-btn" data-loot="money">💰 金钱(万) <span class="count" id="tl-money">0</span></button>
                        <button class="loot-btn" data-loot="exp">📈 经验 <span class="count" id="tl-exp">0</span></button>
                        <button class="loot-btn" data-loot="shoujue">📜 兽决 <span class="count" id="tl-shoujue">0</span></button>
                        <button class="loot-btn" data-loot="lingpai">🎫 令牌 <span class="count" id="tl-lingpai">0</span></button>
                        <button class="loot-btn" data-loot="baoshi">💎 宝石 <span class="count" id="tl-baoshi">0</span></button>
                        <button class="loot-btn" data-loot="caiguo">🍎 彩果 <span class="count" id="tl-caiguo">0</span></button>
                        <button class="loot-btn" data-loot="haima">🐴 海马 <span class="count" id="tl-haima">0</span></button>
                    </div>

                    <div style="background:#eef4fa;border-radius:12px;padding:6px 12px;margin-top:8px;font-size:0.8rem;color:#1f3b53;">
                        📦 当前产出: <span id="trCurrentLootSummary">无</span>
                    </div>
                </div>
            </div>

            <!-- 掉落物价值 -->
            <div class="module">
                <div class="module-header"><div class="title">⚙️ 掉落物价值 (万) <span class="hint">— 根据物价调整</span></div></div>
                <div class="module-body">
                    <div class="tree-price-grid" id="trPriceGrid"></div>
                </div>
            </div>

            <!-- 操作按钮 -->
            <div class="flex-between">
                <span style="font-size:0.7rem;color:#3a5f7a;">🌳 记录完整产出后点击「结算此树」</span>
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                    <button class="btn-complete" id="trCompleteBtn">🌳 结算此树</button>
                    <button class="btn-reset" id="trResetBtn">🗑️ 重置当前</button>
                </div>
            </div>

            <!-- 种树记录 -->
            <div class="module" style="margin-top:14px;">
                <div class="module-header">
                    <div class="title">📜 种树记录 <span class="hint" id="trHistoryCount">共 0 棵</span></div>
                    <div style="display:flex;gap:6px;flex-wrap:wrap;">
                        <button class="btn-analysis" id="trAnalysisToggleBtn">📊 数据分析</button>
                    </div>
                </div>
                <div class="module-body">
                    <div class="analysis-panel" id="trAnalysisPanel" style="display:none;">
                        <div class="tree-analysis-grid" id="trAnalysisGrid">
                            <div class="a-item"><div class="a-num" id="taTotal">0</div><div class="a-label">总棵数</div></div>
                            <div class="a-item"><div class="a-num" id="taCost">0</div><div class="a-label">总成本(万)</div></div>
                            <div class="a-item"><div class="a-num" id="taIncome">0</div><div class="a-label">总收入(万)</div></div>
                            <div class="a-item a-profit" id="taProfitWrap"><div class="a-num" id="taProfit">0</div><div class="a-label">总利润(万)</div></div>
                            <div class="a-item"><div class="a-num" id="taRate">0%</div><div class="a-label">盈利率</div></div>
                        </div>
                        <div style="font-size:0.85rem;color:#5a7a94;text-align:center;padding:4px 0;" id="taSummary">总结: 尚未有种树记录，开始种树吧！</div>
                    </div>
                    <div class="table-wrap" style="max-height:300px;">
                        <table>
                            <thead><tr><th>#</th><th>📅 日期</th><th>🌱 成本</th><th>💰 收入</th><th>📈 利润</th><th>🔄 摇树</th><th>📦 产出</th><th>⚙️</th></tr></thead>
                            <tbody id="trHistoryBody"><tr><td colspan="8" style="padding:30px 0;color:#6c87a0;text-align:center;font-style:italic;">暂无种树记录</td></tr></tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    },

    // ========== 绑定事件 ==========
    bindEvents() {
        const container = document.getElementById('treePlantContainer');
        if (!container) return;

        // 事件按钮 - 累加模式（点击一次加一次，不限次数）
        container.addEventListener('click', (e) => {
            const btn = e.target.closest('#trEventsGrid .evt-btn');
            if (btn) {
                this.addEvent(btn.dataset.event);
                return;
            }
        });

        // Loot按钮
        container.addEventListener('click', (e) => {
            const btn = e.target.closest('#trLootGrid .loot-btn, #trLootExtra .loot-btn');
            if (btn) {
                this.addLoot(btn.dataset.loot);
                return;
            }
        });

        // 价格变化
        container.addEventListener('change', (e) => {
            const input = e.target.closest('#trPriceGrid input');
            if (input) {
                const key = input.dataset.key;
                let val = parseFloat(input.value);
                if (isNaN(val) || val < 0) val = 0;
                this.prices[key] = val;
                this.saveData();
                this.render();
            }
        });

        // 按钮
        document.getElementById('trCompleteBtn').addEventListener('click', () => this.settle());
        document.getElementById('trResetBtn').addEventListener('click', () => this.reset());
        document.getElementById('trUndoBtn').addEventListener('click', () => this.undo());

        // 数据分析
        let analysisVisible = false;
        document.getElementById('trAnalysisToggleBtn').addEventListener('click', function() {
            analysisVisible = !analysisVisible;
            document.getElementById('trAnalysisPanel').style.display = analysisVisible ? 'block' : 'none';
            this.textContent = analysisVisible ? '📊 隐藏分析' : '📊 数据分析';
            this.classList.toggle('active', analysisVisible);
            if (analysisVisible) TreePlantModule.updateAnalysis();
        });
    },

    // ========== 核心业务 ==========
    // addLoot: 点击一次加1个，不限次数
    addLoot(key) {
        if (this.current.isSettled) {
            alert('这棵树已结算，请开始新的记录！');
            return;
        }
        if (this.current.loot[key] === undefined) this.current.loot[key] = 0;
        this.current.loot[key]++;
        this.saveData();
        this.render();
    },

    // addEvent: 累加模式，点击一次加一次，不限次数
    addEvent(evt) {
        if (this.current.isSettled) {
            alert('这棵树已结算，请开始新的记录！');
            return;
        }

        if (evt === 'none') {
            // 无事件：重置所有事件
            this.current.events = [];
            this.current.shakes = this.current.baseShakes;
        } else {
            // 累加模式：直接push，不判断是否已存在
            this.current.events.push(evt);

            // 重新计算摇树次数
            this.current.shakes = this.current.baseShakes;
            let hasZaoshu = false;
            for (let e of this.current.events) {
                if (e === 'xiaozai') this.current.shakes += 1;
                else if (e === 'chongzai') this.current.shakes += 2;
                else if (e === 'zaoshu') {
                    hasZaoshu = true;
                }
            }
            // 早熟单独处理：如果有早熟，强制改为6次（最后计算）
            if (hasZaoshu) {
                this.current.shakes = 6;
            }
        }
        this.saveData();
        this.render();
    },

    undo() {
        // 撤销最后一次loot
        let hasLoot = false;
        for (let key of this.LOOT_TYPES.map(t => t.key)) {
            if (this.current.loot[key] > 0) {
                this.current.loot[key]--;
                hasLoot = true;
                break;
            }
        }
        if (!hasLoot) {
            // 如果没有loot，撤销最后一个事件
            if (this.current.events.length > 0) {
                const lastEvt = this.current.events.pop();
                // 重新计算摇树次数
                this.current.shakes = this.current.baseShakes;
                let hasZaoshu = false;
                for (let e of this.current.events) {
                    if (e === 'xiaozai') this.current.shakes += 1;
                    else if (e === 'chongzai') this.current.shakes += 2;
                    else if (e === 'zaoshu') {
                        hasZaoshu = true;
                    }
                }
                if (hasZaoshu) {
                    this.current.shakes = 6;
                }
                alert(`已撤销事件: ${lastEvt}`);
            } else {
                alert('没有可撤销的操作');
                return;
            }
        }
        this.saveData();
        this.render();
    },

    reset() {
        if (confirm('重置当前种树记录？（不会删除已结算的历史）')) {
            this.current = { seedCost: 45, baseShakes: 6, shakes: 6, events: [], loot: {}, isSettled: false };
            this.LOOT_TYPES.forEach(t => {
                if (this.current.loot[t.key] === undefined) this.current.loot[t.key] = 0;
            });
            this.saveData();
            this.render();
        }
    },

    settle() {
        const income = this.calcCurrentIncome();
        const totalLoot = Object.values(this.current.loot).reduce((a, b) => a + b, 0);
        if (totalLoot === 0 && !confirm('当前没有产出记录，确认结算此树？')) return;

        const profit = income.total - this.current.seedCost;
        const lootDetails = [];
        for (let [key, count] of Object.entries(this.current.loot)) {
            if (count > 0) {
                const label = this.LOOT_TYPES.find(t => t.key === key)?.label || key;
                lootDetails.push(`${label}×${count}`);
            }
        }

        const entry = {
            date: new Date().toLocaleString(),
            cost: this.current.seedCost,
            income: income.total,
            profit: profit,
            shakes: this.current.shakes,
            events: [...this.current.events],
            loot: { ...this.current.loot },
            lootDetails: lootDetails,
        };

        this.history.push(entry);
        this.saveData();

        this.current = { seedCost: 45, baseShakes: 6, shakes: 6, events: [], loot: {}, isSettled: false };
        this.LOOT_TYPES.forEach(t => {
            if (this.current.loot[t.key] === undefined) this.current.loot[t.key] = 0;
        });
        this.saveData();
        this.render();

        document.getElementById('settleModalTitle').textContent = '🌳 种树结算报告';
        document.getElementById('settleModalDesc').textContent =
            `🌱 成本 ${entry.cost}万 | 📊 收入 ${entry.income.toFixed(1)}万 | 📈 利润 ${entry.profit.toFixed(1)}万 | 🔄 摇树 ${entry.shakes}次`;
        document.getElementById('settleModalBody').innerHTML =
            `<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px 16px;padding:8px 0;">
                <span>🌱 树苗成本: <strong>${entry.cost}万</strong></span>
                <span>🔄 摇树次数: <strong>${entry.shakes}次</strong></span>
                <span>📦 产出物品: <strong>${lootDetails.length > 0 ? lootDetails.join('; ') : '无'}</strong></span>
                <span>📊 总收入: <strong>${entry.income.toFixed(1)}万</strong></span>
                <span style="grid-column:1/-1;text-align:center;font-size:1.1rem;padding:6px 0;border-top:1px solid #dce5ef;color:${entry.profit>=0?'#2d6b2d':'#c0392b'};">
                    ${entry.profit >= 0 ? '✅' : '❌'} 利润: <strong>${entry.profit.toFixed(1)}万</strong>
                </span>
            </div>`;
        document.getElementById('settleModal').classList.add('show');
    },

    // ========== 更新渲染 ==========
    updateStats() {
        const stats = this.calcStats();
        const el = (id) => document.getElementById(id);
        const setText = (id, val) => { const e = el(id); if (e) e.textContent = val; };

        setText('trTotalCost', stats.totalCost.toFixed(1));
        setText('trTotalIncome', stats.totalIncome.toFixed(1));
        setText('trTotalProfit', stats.totalProfit.toFixed(1));
        setText('trTotalCount', stats.count);
        setText('trAvgProfit', stats.avgProfit.toFixed(1));
        setText('trWinRate', stats.winRate.toFixed(0) + '%');

        const ps = document.getElementById('trProfitStat');
        if (ps) ps.className = 'stat-item' + (stats.totalProfit > 0 ? ' profit' : stats.totalProfit < 0 ? ' loss' : '');
        const rs = document.getElementById('trRateStat');
        if (rs) rs.className = 'stat-item' + (stats.winRate >= 50 ? ' profit' : stats.winRate > 0 ? '' : '');

        this.buildPriceInputs();
    },

    buildPriceInputs() {
        const grid = document.getElementById('trPriceGrid');
        if (!grid || grid.children.length > 0) return;

        let html = '';
        this.LOOT_TYPES.forEach(t => {
            const v = this.prices[t.key] ?? t.defaultPrice;
            html +=
                `<div class="tree-price-item"><label>${t.label}</label><input type="number" step="0.1" min="0" value="${v}" data-key="${t.key}"></div>`;
        });
        grid.innerHTML = html;
    },

    updateCurrent() {
        const stats = this.calcStats();
        const totalTrees = stats.count;
        const el = (id) => document.getElementById(id);
        const setText = (id, val) => { const e = el(id); if (e) e.textContent = val; };

        setText('trCurrentLabel', `第 ${totalTrees + 1} 棵`);
        setText('trSeedCost', this.current.seedCost);
        setText('trBaseShakes', this.current.baseShakes);
        setText('trCurrentShakes', this.current.shakes);
        setText('trEventsDisplay', this.current.events.length > 0 ? this.current.events.join(' + ') : '无');

        // 事件按钮 - 累加模式不再需要高亮，因为点击一次加一次
        // 但仍然显示事件列表

        // 更新loot计数
        this.LOOT_TYPES.forEach(t => {
            const e = document.getElementById(`tl-${t.key}`);
            if (e) e.textContent = this.current.loot[t.key] || 0;
        });

        // 当前产出汇总
        const income = this.calcCurrentIncome();
        const summary = document.getElementById('trCurrentLootSummary');
        if (summary) summary.textContent = income.details.length > 0 ? income.details.join('; ') : '无';
    },

    updateHistory() {
        const tbody = document.getElementById('trHistoryBody');
        const countEl = document.getElementById('trHistoryCount');
        if (countEl) countEl.textContent = `共 ${this.history.length} 棵`;

        if (this.history.length === 0) {
            if (tbody) tbody.innerHTML =
                '<tr><td colspan="8" style="padding:30px 0;color:#6c87a0;text-align:center;font-style:italic;">暂无种树记录</td></tr>';
            return;
        }

        let html = '';
        const list = this.history.slice().reverse();
        for (let i = 0; i < list.length; i++) {
            const h = list[i];
            const row = list.length - i;
            const pc = h.profit >= 0 ? 'profit-positive' : 'profit-negative';
            const idx = this.history.indexOf(h);
            const lootStr = h.lootDetails ? h.lootDetails.join('; ') : '-';

            html += `<tr>
                <td style="font-weight:700;color:#1f3b53;background:#f5f8fc;">${row}</td>
                <td>${h.date || '未知'}</td>
                <td>${(h.cost || 0).toFixed(1)}</td>
                <td>${(h.income || 0).toFixed(1)}</td>
                <td class="${pc}">${(h.profit || 0).toFixed(1)}</td>
                <td>${h.shakes || 0}</td>
                <td style="font-size:0.7rem;max-width:150px;overflow:hidden;text-overflow:ellipsis;">${lootStr}</td>
                <td><button class="del-btn" data-idx="${idx}" style="background:#f5d0d0;border:none;border-radius:30px;padding:2px 12px;font-size:0.65rem;cursor:pointer;color:#8f3a3a;font-weight:700;">✕</button></td>
            </tr>`;
        }
        if (tbody) tbody.innerHTML = html;

        if (tbody) {
            tbody.querySelectorAll('.del-btn').forEach(b => {
                b.removeEventListener('click', b._delHandler);
                b._delHandler = () => {
                    const idx = parseInt(b.dataset.idx);
                    if (idx >= 0 && idx < this.history.length) {
                        this.history.splice(idx, 1);
                        this.saveData();
                        this.render();
                    }
                };
                b.addEventListener('click', b._delHandler);
            });
        }
    },

    updateAnalysis() {
        const stats = this.calcStats();
        const el = (id) => document.getElementById(id);
        const setText = (id, val) => { const e = el(id); if (e) e.textContent = val; };

        setText('taTotal', stats.count);
        setText('taCost', stats.totalCost.toFixed(1));
        setText('taIncome', stats.totalIncome.toFixed(1));
        setText('taProfit', stats.totalProfit.toFixed(1));
        setText('taRate', stats.winRate.toFixed(0) + '%');

        const wrap = document.getElementById('taProfitWrap');
        if (wrap) wrap.className = 'a-item' + (stats.totalProfit >= 0 ? ' a-profit' : ' a-loss');

        const summary = document.getElementById('taSummary');
        if (summary) {
            summary.textContent = stats.count === 0 ?
                '总结: 尚未有种树记录，开始种树吧！' :
                `总结: 共种植 ${stats.count} 棵，总利润 ${stats.totalProfit.toFixed(1)} 万，盈利率 ${stats.winRate.toFixed(0)}%，平均每棵 ${stats.avgProfit.toFixed(1)} 万。`;
        }
    }
};

// 自动初始化
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => TreePlantModule.init());
} else {
    TreePlantModule.init();
}